module.exports = {
    mongoURI: 'mongodb+srv://locdir:direct123%21@cluster0-koe9m.mongodb.net/test?retryWrites=true&w=majority'
}